import PySimpleGUI as sg

sg.theme("DarkRed1")
sg.theme_text_color("#6666FF")
window = sg.Window(title="Profile",
                   layout=[[sg.Text("NPM      : 2210010658")],
                           [sg.Text("Nama    : Muhammad Ridha Firdaus")],
                           [sg.Text("Kelas    : 5B NONREG")],
                           [sg.Text("Kelas    : Pemrograman Visual 3")]],
                            size=(500, 250),
                            font=("Arial", 18))
                            
window.read()
window.close()